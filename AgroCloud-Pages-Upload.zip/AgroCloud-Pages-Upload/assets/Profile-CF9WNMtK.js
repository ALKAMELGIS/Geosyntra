import{j as e}from"./index-BrFnWv0L.js";function s(){return e.jsx("div",{className:"page"})}export{s as default};
